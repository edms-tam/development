# Responsive React Dashboard with Tailwind

A Pen created on CodePen.io. Original URL: [https://codepen.io/dilums/pen/ZEBowxX](https://codepen.io/dilums/pen/ZEBowxX).

Inspiration [Integration dashboard dark mode by  Alexey Savitskiy](https://dribbble.com/shots/14710948-Integration-dashboard-dark-mode)
                          
                      
This demo is also available on GitHub. [Here is the link](https://github.com/dilums/react-dashboard)
                          